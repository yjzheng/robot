import subprocess
from optparse import OptionParser

parser = OptionParser()
parser.add_option("--cli", dest="cli", help="Arduino cli", metavar="CLI", default=None)
parser.add_option("--port", dest="port", help="Serial port named PORT", metavar="PORT", default=None)
parser.add_option("--baudrate", dest="baudrate", help="Communication speed", metavar="BAUDRATE", default="115200")

options, args = parser.parse_args()

if options.cli != None:

    comm_port = None
    baud_rate = "115200"

    if options.port == None:
        board_list = [
            options.cli,
            "board",
            "list"
        ]
        board_list_filename = "board_list.info"
        list_file = open(board_list_filename,'tw')
        rc = subprocess.call(board_list, stdout=list_file )
        list_file.close()
        board_list_info = open(board_list_filename,'tr', encoding='utf-8')
        board_list_all = board_list_info.readlines()
        for board_list in board_list_all:
            #print(len(board_list))
            #print(board_list)
            if len(board_list) > 1:
                info = board_list.split(' ')
                print("info:", info)
                if info[-1].startswith('arduino:'):
                    comm_port = info[0]
                    print("comm_port:", comm_port)
                    break
        board_list_info.close()

    if options.baudrate != None:
        baud_rate = options.baudrate

    try:
        board_list = [
            options.cli,
            "monitor",
            "-p", comm_port,
            "--config", baud_rate
        ]
        #board_list_filename = "board_list.info"
        #list_file = open(board_list_filename,'tw')
        #rc = subprocess.call(board_list, stdout=list_file )
        rc = subprocess.call(board_list )
        #list_file.close()
    except:
        pass