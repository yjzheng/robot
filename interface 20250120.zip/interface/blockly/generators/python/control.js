'use strict';

goog.provide('Blockly.Python.loops');

goog.require('Blockly.Python');


Blockly.Python.controls_for = function() {
  // For loop.
  var variable0 = Blockly.Python.variableDB_.getName(
      this.getFieldValue('VAR'), Blockly.Variables.NAME_TYPE);
  var argument0 = Blockly.Python.valueToCode(this, 'FROM',
      Blockly.Python.ORDER_ASSIGNMENT) || '0';
  var argument1 = Blockly.Python.valueToCode(this, 'TO',
      Blockly.Python.ORDER_ASSIGNMENT) || '0';
  var argument2 = Blockly.Python.valueToCode(this, 'BY',
    Blockly.Python.ORDER_ASSIGNMENT) || '0';
    var branch = Blockly.Python.statementToCode(this, 'DO');
  if (Blockly.Python.INFINITE_LOOP_TRAP) {
    branch = Blockly.Python.INFINITE_LOOP_TRAP.replace(/%1/g,
        '\'' + this.id + '\'') + branch;
  }
  var code;
  // Both arguments are simple numbers.
  var up = parseFloat(argument0) <= parseFloat(argument1);
  //for i in range(len(sit_pose)):
  if(argument2 > 0) {
    if( argument2 == 1) {
      if( argument0 == 0) {
        code = 'for ' + variable0 + ' in range( ' + argument1 + '+1):\n' +
          branch + '\n';
  } else {
        code = 'for ' + variable0 + ' in range( ' + argument0 + ', ' +
            argument1 + '+1):\n' +
            branch + '\n';
      }
    } else {
      code = 'for ' + variable0 + ' in range( ' + argument0 + ', ' + argument1 + '+1, ' + 
          argument2 + '):\n' +
          branch + '\n';
    }
  } else {
    code = 'for ' + variable0 + ' in range( ' + argument0 + ', ' + argument1 + '-1, ' + 
    argument2 + '):\n' +
    branch + '\n';
  }
  return code;
};
