goog.provide('Blockly.Python.PCA9685');

goog.require('Blockly.Python');

Blockly.Python.servo_rotate_to_angle = function() {
    var channel = Blockly.Python.valueToCode(this, 'CHANNEL', Blockly.Python.ORDER_ATOMIC);
    var angle = Blockly.Python.valueToCode(this, 'ANGLE', Blockly.Python.ORDER_ATOMIC);

    Blockly.Python.definitions_['import_PCA9685'] = 'import PCA9685\n';
    Blockly.Python.definitions_['var_new_PCA9685'] = 'pwm = PCA9685.PCA9685()\n' + 'pwm.set_pwm_freq(50)\n';

    var code = 'pwm.rotate_to_angle(' + channel + ',' + angle + ')\n';
    return code;
};

Blockly.Python.servo_move_to = function() {
    var adjust = Blockly.Python.valueToCode(this, 'ADJUST', Blockly.Python.ORDER_ATOMIC);
    var current = Blockly.Python.valueToCode(this, 'CURRENT', Blockly.Python.ORDER_ATOMIC);
    var target = Blockly.Python.valueToCode(this, 'TARGET', Blockly.Python.ORDER_ATOMIC);
    var time = Blockly.Python.valueToCode(this, 'TIME', Blockly.Python.ORDER_ATOMIC);

    Blockly.Python.definitions_['import_PCA9685'] = 'import PCA9685\n';
    Blockly.Python.definitions_['var_new_PCA9685'] = 'pwm = PCA9685.PCA9685()\n' + 'pwm.set_pwm_freq(50)\n';

    var code = 'pwm.moveTo(' + adjust + ',' + current + ',' + target + ',' + time + ')\n';
    return [code, Blockly.Python.ORDER_ATOMIC];
};

Blockly.Python.define_channel_angles = function() {
    //var code = window.parseInt(this.itemCount_);
    var code = "[";
    for (var i = 0; i < 16; i++) {
        if( i != 0) code += ",";
        code += Blockly.Python.valueToCode(this, 'CHANNEL' + i,
            Blockly.Python.ORDER_ASSIGNMENT) || '0';
    }
    code += ']';
    var order = Blockly.Python.ORDER_ATOMIC;
    return [code, order];
};