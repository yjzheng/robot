goog.provide('Blockly.Arduino.md_max72xx');

goog.require('Blockly.Arduino');

Blockly.Arduino.md_max72xx_init = function() {
    var cs_pin = this.getFieldValue('CS');
    Blockly.Arduino.definitions_['define_md_max72xx'] = '#include <MD_MAX72xx.h>\n';
    Blockly.Arduino.definitions_['var_md_max72xx'] = 'MD_MAX72XX mx = MD_MAX72XX(MD_MAX72XX::PAROLA_HW, ' + cs_pin + ', 11);\n';

    Blockly.Arduino.setups_['setup_dm_max72xx_begin'] = 'mx.begin();';

    var code = '';
    return code;
};

Blockly.Arduino.md_max72xx_clear = function() {
    var code = 'md.clear();\n';
    return code;
}

Blockly.Arduino.md_max72xx_scroll_text = function() {
    var function_code = 'void md_max72xx_scroll_text(const char *p)\n' +
        '{\n'+
        '\tuint8_t charWidth, cBuf[8];\n'+
        '\tmx.clear();\n'+
        '\twhile (*p != \'\0\') {\n' +
        '\t\tcharWidth = mx.getChar(*p++, sizeof(cBuf) / sizeof(cBuf[0]), cBuf);\n'+
        '\t\tfor (uint8_t i=0; i<=charWidth; i++) {\n'+
        '\t\t\tmx.transform(MD_MAX72XX::TSL);\n'+
        '\t\t\tif (i < charWidth)\n'+
        '\t\t\t\tmx.setColumn(0, cBuf[i]);\n'+
        '\t\t\tdelay(100);\n'+
        '\t\t}\n'+
        '\t}\n'+
        '}\n';
    Blockly.Arduino.definitions_['define_md_max72xx_scroll_text_function'] = function_code;

    var text = Blockly.Arduino.valueToCode(this, 'TEXT', Blockly.Arduino.ORDER_ATOMIC);
    var code = 'md_max72xx_scroll_text('+text+');';
    return code;
}

Blockly.Arduino.md_max72xx_set_point = function() {
    var x = Blockly.Arduino.valueToCode(this, 'X', Blockly.Arduino.ORDER_ATOMIC);
    var y = Blockly.Arduino.valueToCode(this, 'Y', Blockly.Arduino.ORDER_ATOMIC);
    var on = Blockly.Arduino.valueToCode(this, 'ON', Blockly.Arduino.ORDER_ATOMIC);
    var code = 'mx.setPoint('+x+','+y+','+on+');';
    return code;
}

Blockly.Arduino.md_max72xx_set_row = function() {
    var row = Blockly.Arduino.valueToCode(this, 'ROW', Blockly.Arduino.ORDER_ATOMIC);
    var data = Blockly.Arduino.valueToCode(this, 'DATA', Blockly.Arduino.ORDER_ATOMIC);
    var code = 'mx.setRow('+row+','+data+');';
    return code;
}
