goog.provide('Blockly.Arduino.dht11');

goog.require('Blockly.Arduino');

Blockly.Arduino.dht11_read = function() {
  var dropdown_pin = this.getFieldValue('PIN');
  var var_temperature = Blockly.Arduino.variableDB_.getName(
    this.getFieldValue('VAR_TEMP'), Blockly.Variables.NAME_TYPE);
  var var_humidity = Blockly.Arduino.variableDB_.getName(
    this.getFieldValue('VAR_HUMIDITY'), Blockly.Variables.NAME_TYPE);
  
  Blockly.Arduino.definitions_['define_sample_dht'] = '#include <SimpleDHT.h>\n';
  Blockly.Arduino.definitions_['var_sample_dht' + dropdown_pin] = 'SimpleDHT11 dht11_'+dropdown_pin+';\n';

  var code = 'dht11_' + dropdown_pin + '.read(' + dropdown_pin + ',(byte *)&' + var_temperature + ',(byte *)&' + var_humidity + ', NULL)';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};
