goog.provide('Blockly.Arduino.LiquidCrystal');

goog.require('Blockly.Arduino');

Blockly.Arduino.LiquidCrystal_init = function() {
    Blockly.Arduino.definitions_['define_LiquidCrystal'] = '#include <LiquidCrystal_I2C.h>\n';
    Blockly.Arduino.definitions_['var_LiquidCrystal'] = '// set the LCD address to 0x27 for a 16 chars and 2 line display\n'+
        'LiquidCrystal_I2C lcd(0x27,16,2);\n';
    Blockly.Arduino.setups_['setup_led_init'] = 'lcd.init();';

    var code = '';
    return code;
};

Blockly.Arduino.LiquidCrystal_backlight = function() {
    var code = 'lcd.backlight();\n';
    return code;
};

Blockly.Arduino.LiquidCrystal_setCursor = function() {
    var x = Blockly.Arduino.valueToCode(this, 'X', Blockly.Arduino.ORDER_ATOMIC);
    var y = Blockly.Arduino.valueToCode(this, 'Y', Blockly.Arduino.ORDER_ATOMIC);
    var code = 'lcd.setCursor('+x+','+y+');\n';
    return code;
}

Blockly.Arduino.LiquidCrystal_print = function() {
    var text = Blockly.Arduino.valueToCode(this, 'TEXT', Blockly.Arduino.ORDER_ATOMIC);
    var code = 'lcd.print('+text+');\n';
    return code;
}

