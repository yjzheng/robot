goog.provide('Blockly.Arduino.ultrasonic');

goog.require('Blockly.Arduino');

Blockly.Arduino.ultrasonic_read = function() {
  var trigger_pin = this.getFieldValue('TRIG');
  var echo_pin = this.getFieldValue('ECHO');
  var unit = this.getFieldValue('UNIT');

  Blockly.Arduino.definitions_['define_ultrasonic'] = '#include <Ultrasonic.h>\n';
  Blockly.Arduino.definitions_['var_ultrasonic' + trigger_pin] = 'Ultrasonic ultrasonic_'+trigger_pin+'('+trigger_pin+','+echo_pin+');\n';

  var code = 'ultrasonic_' + trigger_pin + '.read(' + unit + ')';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};
  