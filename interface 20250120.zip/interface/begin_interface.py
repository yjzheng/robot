import os
import subprocess

index_file = os.path.join(os.getcwd(),'blockly', 'apps', 'robot', 'index.html')
print(index_file)

try:
    board_list = [
        "open -n /Applications/Google\ Chrome.app",
        #"C:\Program Files\Google\Chrome\Application\chrome.exe",
        index_file
    ]
    #rc = subprocess.call(board_list )
    os.system('open -n "/Applications/Google Chrome.app" --args '+index_file)
    print("rc="+str(rc))
except:
    print("except!")
    pass