import os
import subprocess
import platform

index_file = os.path.join(os.getcwd(),'blockly', 'apps', 'robot', 'index.html')
print(index_file)

try:
    if platform.system() == 'Windows':
        board_list = [
            "C:\Program Files\Google\Chrome\Application\chrome.exe",
            index_file
        ]
        rc = subprocess.call(board_list )
        print("rc="+str(rc))
    else:
        board_list = [
            "open -n /Applications/Google\ Chrome.app",
            index_file
        ]
        os.system('open -n "/Applications/Google Chrome.app" --args '+index_file)
except:
    print("except!")
    pass