goog.provide('Blockly.Blocks.PCA9685');

goog.require('Blockly.Blocks');

Blockly.Blocks['servo_rotate_to_angle'] = {
    init: function() {
        this.appendDummyInput()
            .appendField('Rotate servo(轉動舵機)');
        this.appendValueInput('BOARD')
            .setCheck('Number')
            .appendField('board #(0,1):');
        this.appendValueInput('CHANNEL')
            .setCheck('Number')
            .appendField('channel(0~15):');
        this.appendValueInput('ANGLE')
            .setCheck('Number')
            .appendField('angle(0~180):');
        this.setInputsInline(true)
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
        this.setHelpUrl('');
        this.setColour(60);
    }
};

Blockly.Blocks['servo_move_to'] = {
    init: function() {
        this.appendDummyInput()
            .appendField('Rotate all servos(轉動全部舵機)');
        this.appendValueInput('BOARD')
            .setCheck('Number')
            .appendField('board #(0,1):');
        this.appendValueInput('ADJUST')
            .setCheck('Array')
            .appendField('adjust(調整):');
        this.appendValueInput('CURRENT')
            .setCheck('Array')
            .appendField('current(目前):');
        this.appendValueInput('TARGET')
            .setCheck('Array')
            .appendField('move to(移動到):');
        this.appendValueInput('TIME')
            .setCheck('Number')
            .appendField('time(完成時間)(ms):');
        this.setInputsInline(true)
        this.setTooltip('');
        this.setHelpUrl('');
        this.setOutput(true, 'Array');
        this.setColour(60);
    }
};

Blockly.Blocks['define_channel_angles'] = {
    init: function() {
        this.appendDummyInput()
            .appendField('Define Channel Angles(定義管道角度)');
        this.appendValueInput('CHANNEL0')
            .setCheck('Number')
            .appendField('#0:');
        this.appendValueInput('CHANNEL1')
            .setCheck('Number')
            .appendField('#1:');
        this.appendValueInput('CHANNEL2')
            .setCheck('Number')
            .appendField('#2:');
        this.appendValueInput('CHANNEL3')
            .setCheck('Number')
            .appendField('#3:');
        this.appendValueInput('CHANNEL4')
            .setCheck('Number')
            .appendField('#4:');
        this.appendValueInput('CHANNEL5')
            .setCheck('Number')
            .appendField('#5:');
        this.appendValueInput('CHANNEL6')
            .setCheck('Number')
            .appendField('#6:');
        this.appendValueInput('CHANNEL7')
            .setCheck('Number')
            .appendField('#7:');
        this.appendValueInput('CHANNEL8')
            .setCheck('Number')
            .appendField('#8:');
        this.appendValueInput('CHANNEL9')
            .setCheck('Number')
            .appendField('#9:');
        this.appendValueInput('CHANNEL10')
            .setCheck('Number')
            .appendField('#10:');
        this.appendValueInput('CHANNEL11')
            .setCheck('Number')
            .appendField('#11:');
        this.appendValueInput('CHANNEL12')
            .setCheck('Number')
            .appendField('#12:');
        this.appendValueInput('CHANNEL13')
            .setCheck('Number')
            .appendField('#13:');
        this.appendValueInput('CHANNEL14')
            .setCheck('Number')
            .appendField('#14:');
        this.appendValueInput('CHANNEL15')
            .setCheck('Number')
            .appendField('#15:');
        this.setInputsInline(true)
        this.setTooltip('');
        this.setHelpUrl('');
        this.setOutput(true, 'Array');
        this.setColour(60);
    }
};

Blockly.Blocks['release_devices'] = {
    init: function() {
        this.appendDummyInput()
            .appendField('Release servos(釋放舵機)');
        this.appendValueInput('BOARD')
            .setCheck('Number')
            .appendField('board #(0,1):');
        this.setInputsInline(true)
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
        this.setHelpUrl('');
        this.setColour(60);
    }
};
