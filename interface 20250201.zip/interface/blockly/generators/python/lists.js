
'use strict';

goog.provide('Blockly.Python.lists');

goog.require('Blockly.Python');

Blockly.Python.lists_create_with = function() {
    //var code = window.parseInt(this.itemCount_);
    var code = "[";
    for (var i = 0; i < this.itemCount_; i++) {
        if( i != 0) code += ",";
        code += Blockly.Python.valueToCode(this, 'ADD' + i,
            Blockly.Python.ORDER_ASSIGNMENT) || '0';
    }
    code += ']';
    var order = Blockly.Python.ORDER_ATOMIC;
    return [code, order];
};

Blockly.Python.lists_repeat = function() {
    //current_pose = [ 0 for i in range(16)]
    var item = Blockly.Python.valueToCode(this, 'ITEM', Blockly.Python.ORDER_ASSIGNMENT);
    var repeat_times = Blockly.Python.valueToCode(this, 'NUM', Blockly.Python.ORDER_ASSIGNMENT);
    var code = '[' + item + " for i in range(" + repeat_times + ")]";
    var order = Blockly.Python.ORDER_ATOMIC;
    return [code, order];
};

Blockly.Python.lists_length = function() {
    var value = Blockly.Python.valueToCode(this, 'VALUE', Blockly.Python.ORDER_ASSIGNMENT);
    var code = "len(" + value + ")";
    var order = Blockly.Python.ORDER_ATOMIC;
    return [code, order];
};

Blockly.Python.lists_getIndex = function() {
    var value = Blockly.Python.valueToCode(this, 'VALUE', Blockly.Python.ORDER_ASSIGNMENT);
    var mode = this.getFieldValue('MODE');
    var at = Blockly.Python.valueToCode(this, 'AT', Blockly.Python.ORDER_ASSIGNMENT);
    var code = "";
    if(mode == "GET") {
        code = value + '[' + at + ']';
    }
    var order = Blockly.Python.ORDER_ATOMIC;
    return [code, order];
};