goog.provide('Blockly.Python.PCA9685');

goog.require('Blockly.Python');

Blockly.Python.servo_rotate_to_angle = function() {
    var board = Blockly.Python.valueToCode(this, 'BOARD', Blockly.Python.ORDER_ATOMIC);
    var channel = Blockly.Python.valueToCode(this, 'CHANNEL', Blockly.Python.ORDER_ATOMIC);
    var angle = Blockly.Python.valueToCode(this, 'ANGLE', Blockly.Python.ORDER_ATOMIC);
    var code = '';

    Blockly.Python.definitions_['import_PCA9685'] = 'import PCA9685\n';
    if( board == 0) {
        Blockly.Python.definitions_['var_new_PCA9685_0'] = 'pwm0 = PCA9685.PCA9685(PCA9685.PCA9685_ADDRESS)\n' + 'pwm0.set_pwm_freq(50)\n';
        code = 'pwm0.rotate_to_angle(' + channel + ',' + angle + ')\n';
    } else { 
        Blockly.Python.definitions_['var_new_PCA9685_1'] = 'pwm1 = PCA9685.PCA9685(PCA9685.PCA9685_ADDRESS_2)\n' + 'pwm1.set_pwm_freq(50)\n';
        code = 'pwm1.rotate_to_angle(' + channel + ',' + angle + ')\n';
    }
    return code;
};

Blockly.Python.servo_move_to = function() {
    var board = Blockly.Python.valueToCode(this, 'BOARD', Blockly.Python.ORDER_ATOMIC);
    var adjust = Blockly.Python.valueToCode(this, 'ADJUST', Blockly.Python.ORDER_ATOMIC);
    var current = Blockly.Python.valueToCode(this, 'CURRENT', Blockly.Python.ORDER_ATOMIC);
    var target = Blockly.Python.valueToCode(this, 'TARGET', Blockly.Python.ORDER_ATOMIC);
    var time = Blockly.Python.valueToCode(this, 'TIME', Blockly.Python.ORDER_ATOMIC);
    var code = '';

    Blockly.Python.definitions_['import_PCA9685'] = 'import PCA9685\n';
    if( board == 0) {
        Blockly.Python.definitions_['var_new_PCA9685_0'] = 'pwm0 = PCA9685.PCA9685(PCA9685.PCA9685_ADDRESS)\n' + 'pwm0.set_pwm_freq(50)\n';
        code = 'pwm0.moveTo(' + adjust + ',' + current + ',' + target + ',' + time + ')';
    } else { 
        Blockly.Python.definitions_['var_new_PCA9685_1'] = 'pwm1 = PCA9685.PCA9685(PCA9685.PCA9685_ADDRESS_2)\n' + 'pwm1.set_pwm_freq(50)\n';
        code = 'pwm1.moveTo(' + adjust + ',' + current + ',' + target + ',' + time + ')';
    }

    return [code, Blockly.Python.ORDER_ATOMIC];
};

Blockly.Python.define_channel_angles = function() {
    //var code = window.parseInt(this.itemCount_);
    var code = "[";
    for (var i = 0; i < 16; i++) {
        if( i != 0) code += ",";
        code += Blockly.Python.valueToCode(this, 'CHANNEL' + i,
            Blockly.Python.ORDER_ASSIGNMENT) || '0';
    }
    code += ']';
    var order = Blockly.Python.ORDER_ATOMIC;
    return [code, order];
};

Blockly.Python.release_devices = function() {
    var board = Blockly.Python.valueToCode(this, 'BOARD', Blockly.Python.ORDER_ATOMIC);
    var code = '';

    Blockly.Python.definitions_['import_PCA9685'] = 'import PCA9685\n';
    if( board == 0) {
        Blockly.Python.definitions_['var_new_PCA9685_0'] = 'pwm0 = PCA9685.PCA9685(PCA9685.PCA9685_ADDRESS)\n' + 'pwm0.set_pwm_freq(50)\n';
        code = 'pwm0.set_pwm_freq(50)\n'+'pwm0.set_all_pwm(0,0)\n';
    } else { 
        Blockly.Python.definitions_['var_new_PCA9685_1'] = 'pwm1 = PCA9685.PCA9685(PCA9685.PCA9685_ADDRESS_2)\n' + 'pwm1.set_pwm_freq(50)\n';
        code = 'pwm1.set_pwm_freq(50)\n'+'pwm1.set_all_pwm(0,0)\n';
    }
    return code;
};
