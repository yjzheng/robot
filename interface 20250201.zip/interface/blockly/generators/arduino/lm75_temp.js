goog.provide('Blockly.Arduino.lm75_temp');

goog.require('Blockly.Arduino');

Blockly.Arduino.lm75_read_temp = function() {
  
  Blockly.Arduino.definitions_['define_temp_lm75'] = '#include <Temperature_LM75_Derived.h>\n';
  Blockly.Arduino.definitions_['var_generic_lm75'] = 'Generic_LM75 lm75_temp;\n';

  Blockly.Arduino.setups_['setup_wire_begin'] = 'Wire.begin();';
  var code = 'lm75_temp.readTemperatureC()';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};
