goog.provide('Blockly.Arduino.NeoPixel');

goog.require('Blockly.Arduino');

Blockly.Arduino.NeoPixel_begin = function() {
    var pin = this.getFieldValue('PIN');
    Blockly.Arduino.definitions_['define_NeoPixel'] = '#include <Adafruit_NeoPixel.h>\n';
    Blockly.Arduino.definitions_['var_NeoPixel'] = '#define NUMPIXELS 12\n'+
        'Adafruit_NeoPixel pixels_'+pin+'(NUMPIXELS, '+pin+', NEO_GRB + NEO_KHZ800);\n';

    Blockly.Arduino.setups_['setup_NeoPixel_begin'] = 'pixels_'+pin+'.begin();\n';

    var code = '';
    return code;
};

Blockly.Arduino.NeoPixel_clear = function() {
    var pin = this.getFieldValue('PIN');
    var code = 'pixels_'+pin+'.clear();\n';
    return code;
};

Blockly.Arduino.NeoPixel_setPixelColor = function() {
    var pin = this.getFieldValue('PIN');
    var num = Blockly.Arduino.valueToCode(this, 'NUM', Blockly.Arduino.ORDER_ATOMIC);
    var r = Blockly.Arduino.valueToCode(this, 'R', Blockly.Arduino.ORDER_ATOMIC);
    var g = Blockly.Arduino.valueToCode(this, 'G', Blockly.Arduino.ORDER_ATOMIC);
    var b = Blockly.Arduino.valueToCode(this, 'B', Blockly.Arduino.ORDER_ATOMIC);
    var code = 'pixels_'+pin+'.setPixelColor('+num+', pixels_'+pin+'.Color('+r+','+g+','+b+'));\n';
    return code;
};

Blockly.Arduino.NeoPixel_show = function() {
    var pin = this.getFieldValue('PIN');
    var code = 'pixels_'+pin+'.show();\n';
    return code;
};
