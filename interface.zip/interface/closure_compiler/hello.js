// A simple function.
function hello(longName) {
    alert('Hello, ' + longName);
  }
  hello('New User');