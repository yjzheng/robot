function hello(a){alert("Hello, "+a)}hello("New User");
