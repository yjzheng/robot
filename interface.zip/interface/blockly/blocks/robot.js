goog.provide('Blockly.Blocks.robot');

goog.require('Blockly.Blocks');

Blockly.Blocks['squat'] = {
    init: function() {
        this.appendDummyInput()
            .appendField('Squat(蹲)');
        this.setInputsInline(true)
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
        this.setHelpUrl('');
        this.setColour(60);
    }
};

Blockly.Blocks['toSquat'] = {
    init: function() {
        this.appendDummyInput()
            .appendField('Squat(蹲)');
        this.appendValueInput('TIME')
            .setCheck('Number')
            .appendField('time(完成時間)(ms):');
        this.setInputsInline(true)
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
        this.setHelpUrl('');
        this.setColour(60);
    }
};

Blockly.Blocks['stand'] = {
    init: function() {
        this.appendDummyInput()
            .appendField('Stand(站立)');
        this.appendValueInput('TIME')
            .setCheck('Number')
            .appendField('time(完成時間)(ms):');
        this.setInputsInline(true)
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
        this.setHelpUrl('');
        this.setColour(60);
    }
};

Blockly.Blocks['oneStep'] = {
    init: function() {
        this.appendDummyInput()
            .appendField('One Step(往前一步)');
        this.appendValueInput('TIME')
            .setCheck('Number')
            .appendField('time(完成時間)(ms):');
        this.setInputsInline(true)
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
        this.setHelpUrl('');
        this.setColour(60);
    }
};

Blockly.Blocks['release'] = {
    init: function() {
        this.appendDummyInput()
            .appendField('Release(放鬆)');
        this.setInputsInline(true)
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
        this.setHelpUrl('');
        this.setColour(60);
    }
};
