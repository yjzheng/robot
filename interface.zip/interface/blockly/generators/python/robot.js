goog.provide('Blockly.Python.robot');

goog.require('Blockly.Python');

Blockly.Python.squat = function() {
    var code = '';

    Blockly.Python.definitions_['import_robot'] = 'import robot\n' + 'robot = robot.robot()\n';
    code = 'robot.squat()\n';

    return code;
};

Blockly.Python.toSquat = function() {
    var time = Blockly.Python.valueToCode(this, 'TIME', Blockly.Python.ORDER_ATOMIC);
    var code = '';

    Blockly.Python.definitions_['import_robot'] = 'import robot\n' + 'robot = robot.robot()\n';
    code = 'robot.toSquat(' + time + ')\n';

    return code;
};

Blockly.Python.stand = function() {
    var time = Blockly.Python.valueToCode(this, 'TIME', Blockly.Python.ORDER_ATOMIC);
    var code = '';

    Blockly.Python.definitions_['import_robot'] = 'import robot\n' + 'robot = robot.robot()\n';
    code = 'robot.stand(' + time + ')\n';

    return code;
};

Blockly.Python.oneStep = function() {
    var time = Blockly.Python.valueToCode(this, 'TIME', Blockly.Python.ORDER_ATOMIC);
    var code = '';

    Blockly.Python.definitions_['import_robot'] = 'import robot\n' + 'robot = robot.robot()\n';
    code = 'robot.oneStep(' + time + ')\n';

    return code;
};

Blockly.Python.release = function() {
    var code = '';

    Blockly.Python.definitions_['import_robot'] = 'import robot\n' + 'robot = robot.robot()\n';
    code = 'robot.release()\n';

    return code;
};
