import http.server
import http.server
import itertools
import logging
import platform
import os
import re
import subprocess
import tempfile
import urllib.request, urllib.parse, urllib.error
import threading

logging.basicConfig(level=logging.DEBUG)

def service_thread(argv1):
    exec(argv1)

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_HEAD(self):
        """Send response headers"""
        if self.path != "/":
            return http.server.SimpleHTTPRequestHandler.do_HEAD(self)
        self.send_response(200)
        self.send_header("content-type", "text/html;charset=utf-8")
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

    def do_GET(self):
        """Send page text"""
        if self.path != "/":
            return http.server.SimpleHTTPRequestHandler.do_GET(self)
        else:
            self.send_response(302)
            self.send_header("Location", "/blockly/apps/blocklyduino/index.html")
            self.end_headers()

    def do_POST(self):
        """Save new page text and display it"""
        if self.path != "/":
            return http.server.SimpleHTTPRequestHandler.do_POST(self)

        #options, args = parser.parse_args()

        #length = int(self.headers.getheader('content-length'))
        length = int(self.headers.get('content-length'))
        if length:
            text = self.rfile.read(length)
                        
            print("python-code to upload: ", text)

            if text[0] != '+':
                t1 = threading.Thread(target=service_thread, args=(text,))
                t1.start()
            '''
            dirname = tempfile.mkdtemp()
            python_name = os.path.join(dirname, os.path.basename(dirname)) + ".py"
            print("sketchname="+python_name)
            f = open(python_name, "wb")
            f.write(text + b'\n')
            f.close()
            '''

            '''
            print("compile_args=", compile_args)
            print("Uploading with %s" % (" ".join(compile_args)))
            rc = subprocess.call(compile_args)

            if not rc == 0:
                print("arduino --upload returned " + repr(rc))                            
                self.send_response(400)
            else:
                self.send_response(200)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
            '''    
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            #os.remove(python_name)
            #os.rmdir(dirname)
        else:
            self.send_response(400)


if __name__ == '__main__':
    try:
        server = http.server.HTTPServer(('', 55053), Handler)
        server.pages = {}
        server.serve_forever()
    except:
        pass